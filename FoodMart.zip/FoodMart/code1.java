package FoodMart;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Product extends code1 {
	static ArrayList<String> products = new ArrayList<String>(
			Arrays.asList("beef", "chicken", "mutton", "potates", "tomatoes", "onions", "milk", "butter", "cheese"));

	static ArrayList<Integer> items = new ArrayList<Integer>(Arrays.asList(0, 0, 0, 0, 0, 0, 0, 0, 0));

	public void set_beef(int i) {
		items.set(0, i);
		//System.out.println(items);

	}

	public void set_chicken(int i) {
		items.set(1, i);

	}

	public void set_mutton(int i) {
		items.set(2, i);

	}

	public void set_potatoes(int i) {
		items.set(3, i);

	}

	public void set_tomatoes(int i) {
		items.set(4, i);

	}

	public void set_onion(int i) {
		items.set(5, i);

	}

	public void set_milk(int i) {
		items.set(6, i);

	}

	public void set_butter(int i) {
		items.set(7, i);

	}

	public void set_cheese(int i) {
		items.set(8, i);

	}

}

class Prices {
	static ArrayList<Integer> individual_price;
//	Product p = new Product();
	int sum;
	String strg;

	public Prices() {

		ArrayList<Integer> price = new ArrayList<Integer>(Arrays.asList(1000, 750, 1600, 100, 250, 150, 180, 80, 350));
		individual_price = calculate(Product.items, price);
		
		sum = individual_price.stream().mapToInt(Integer::intValue).sum();

	}

	public static ArrayList<Integer> calculate(ArrayList<Integer> quantity, ArrayList<Integer> price) {
		ArrayList<Integer> ind_price = new ArrayList<Integer>();
		for (int i = 0; i <quantity.size(); i++) {
			//System.out.println(quantity.size());
			int a =quantity.get(i);
			int b =price.get(i);
			int x = a*b;
			ind_price.add(x);
		//	System.out.println(x);

		}
		return ind_price;

	}

	public String toString() {
		strg ="   Name     "+       "quantity     "+"price \n";
		for(int num=0 ; num<Product.products.size(); num++) {
			
			
		
			strg+=num+") "+ Product.products.get(num)+"      "+Product.items.get(num)+"          "+Prices.individual_price.get(num) +"\n";
			
					
		
		}
		strg+="Total : "+sum+"\n";
		return strg;
	

	}
}

class code1 {
	static Product p = new Product();
	
	
	public static void  menu() {
		
		
			System.out.println("                Menu \n" + "A)               MEAT\n" + "0)  beef \n" + "1)  chicken \n"
					+ "2)  mutton \n" + "\n" + "B)               VEGETABLES \n" + "3   potatoes \n" + "4   tomatoes \n"
					+ "5   onions \n" + "\n" + "C)                DAIRY \n" + "6   milk \n" + "7   butter \n"
					+ "8   cheese \n"
					+"                  Other Options \n"
					+"D) show cart \n"
					+"E)  remove product \n"
					+"f)   buy \n"
					+"g)   logout");
			while (true) {
			Scanner in = new Scanner(System.in);
			System.out.println("ENTER MART SECTION (A->I)or(a->i) \n");
			char sec = in.next().charAt(0);
			if (sec == 'A' || sec == 'a') {
				System.out.println("ENTER PRODUCT NUMBER (0->2):");
				int i = in.nextInt();
				if (i == 0 || i == 1 || i == 2) {
					System.out.println("Enter Quantity");
					int n = in.nextInt();
					if (i == 0) {
						p.set_beef(n);
					} else if (i == 1) {
						p.set_chicken(n);
					} else if (i == 2) {
						p.set_mutton(n);
					}
					else {
						System.out.println("wrong input");
					}
				}
			}
				
				
				

			 else if (sec == 'B' || sec == 'b') {
				System.out.println("ENTER PRODUCT NUMBER (3->5):");
				int i = in.nextInt();
				if (i == 3 || i == 4 || i == 5) {
					System.out.println("Enter Quantity");
					int n = in.nextInt();
					if (i == 3) {
						p.set_potatoes(n);
					} else if (i == 4) {
						p.set_tomatoes(n);
					} else if (i == 5) {
						p.set_onion(n);
					}
					else {
						System.out.println("wrong input");
					}
				}

			} else if (sec == 'C' || sec == 'c') {
				System.out.println("ENTER PRODUCT NUMBER (6->8):");
			
				int i = in.nextInt();
				if (i == 6 || i == 7 || i == 8) {
					System.out.println("Enter Quantity");
					int n = in.nextInt();
					if (i == 6) {
						p.set_milk(n);
					} else if (i == 7) {
						p.set_butter(n);
					} else if (i == 8) {
						p.set_cheese(n);
					}
					else {
						System.out.println("wrong input");
					}
				}
			}
			else if(sec=='D' || sec=='d') {
				Prices pr = new Prices();// ma prices ko uper declare krrha tha product k sth jiski waja sa  constructor tab chal rh THA JAB PRODUNTC KI QUANTITY
				System.out.println(pr);// 0 HOTI THI JAB K USAY TAB TAB BAR BAR CHALNA THA UPDATE HNY K LIA JAB JAB MA D DABATA TAKY CONS BAR BAR NEW VALUES K LIA CALL HOO....
				}  // JIN CHEAZON KO USE KRNA HOTA HY UNKO CLAAASSS K BILKUL NECHY LIKHTy
			else if( sec=='E' || sec=='e'){
				Scanner ins = new Scanner(System.in);
				System.out.println("Enter product number you want to remove: ");
				int n=ins.nextInt();
				System.out.println(p.products.get(n)+"");
				p.items.set(n,0);
			}                    
			else if (sec=='F' || sec=='f') {
				Prices pp=new Prices();
				System.out.println("                 YOUR CART \n");
				System.out.println(pp);
				Scanner sc=new Scanner(System.in);
				System.out.println("Plz confirm your order . yes/YES");
				String a =sc.next();
				if (a.equals("yes")||a.equals("YES")) {
					File file=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\database.txt");
					try {
						BufferedWriter bw=new BufferedWriter( new FileWriter(file,true));
						bw.write(pp.toString()+"\n");
						bw.close();
						
						//bw.write(System.out.println(pp));
						
						
	
						
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				}
				
				
			}
			else {                    
				         // CLASS NAME SA KOI NAME CHANGE KRINGA TO WOH HR OBJECT K LIA CHANGE HOJATA HY JESAY YHN STR MA KIA YE ZARORI THA WRNA BHUND HOTA AGER THIS WAGERA LIKHTY 
			
					System.out.println("thanks"); 
					break;
				}
				
			}
		}

	}
	
