package FoodMart;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

class login_area{
	int inp;
	String name;
	String pass;
	File file;
	File file2;
	
	String[] l;
//clear() method does simple thing. It iterates the backing array inside arraylist and assign all elements 'null' value and set the size attribute to '0'
	public void login_portal() {
		Scanner in=new Scanner(System.in);
		System.out.println("1) Customer Login Area \n"
				+"2) Administrator Login Area");
		System.out.println("enter your choice");
		inp=in.nextInt();
		file=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\costomer_db.txt");
		file2=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\database.txt");
		
		if(inp==1) {
			System.out.println("Enter User Name");
			name=in.next();
			System.out.println("Enter User Password");
			pass=in.next();
		////////	=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\costomer_db.txt");
			try {
				code1 c1=new code1();
				Scanner text=new Scanner(file);
				while(text.hasNextLine()) {
					String line=text.nextLine();
					l=line.split(" ");//jahan space woh alag string.. and make array.
				
					
					if(name.equals(l[0]) && pass.equals(l[1])) {
					//	file2=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\database.txt");
						BufferedWriter bw=new BufferedWriter(new FileWriter(file2,true));
						bw.write("Name : "+name+"\n");
						
						LocalDate myObj = LocalDate.now();
						LocalTime myObj1=LocalTime.now();                                   // Create a date object
					    bw.write(myObj.toString()+"\n");
					    bw.write(myObj1.toString()+"\n");
					    
					    
						bw.close();
						//System.out.println(l[0]+l[1]);
						System.out.println("Welcome To Fresh Mart");
						
						c1.menu();
						break;
					}
				}
				if(!name.equals(l[0]) || !pass.equals(l[1])) {
					Scanner input=new Scanner(file);
					System.out.println("you have to create account first");
					System.out.println("Do you want to create account ? than press YES/yes \n");
					Scanner ins=new Scanner(System.in);
					String ans=ins.next();
					if(ans.equals("yes")|| ans.equals("YES")) {
						System.out.println("Enter Your Name");
						String n =ins.next();
						System.out.println("Enter Your Password");
						String p =ins.next();
						BufferedWriter bw=new BufferedWriter(new FileWriter(file,true));
						BufferedWriter bw1=new BufferedWriter(new FileWriter(file2,true));
						bw1.write(n+"\n");
						
						LocalDate myObj = LocalDate.now();
						LocalTime myObj1=LocalTime.now();                                   // Create a date object
					    bw1.write(myObj.toString()+"\n");
					    bw1.write(myObj1.toString()+"\n");
						
						
						
						
						bw.newLine();
						bw.write(n+" "+p);
						bw.close();
						bw1.close();
						
						
						System.out.println("Welcome To Fresh Mart");
						
						c1.menu();
					
						
						
					}
					else {
						System.out.println("ok carry on :)");
					}
					
				}
			
			} catch (FileNotFoundException e) {
				System.out.println("file not found: "+file.toString());
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		else if(inp==2){
			Scanner i = new Scanner(System.in);
			System.out.println("Enter Your Name");
			File file1=new File("C:\\Users\\Danish Kamal\\Desktop\\java programming\\java_programming\\src\\FoodMart\\database.txt");
			String n =i.next();
			System.out.println("Enter Your Password");
			String p =i.next();
			try {
				Scanner text=new Scanner(file1);
				while(text.hasNextLine()) {
					System.out.println(text.nextLine());
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
	}
}




public class code2 {
	public static void main(String[] args) {
		login_area la=new login_area();
		la.login_portal();
		
	}
	

}
